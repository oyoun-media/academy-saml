<input type="hidden" id="SAMLRequest" name="SAMLRequest" value="{{ request('SAMLRequest') }}" />
<input type="hidden" id="RelayState" name="RelayState" value="{{ request('RelayState') }}" />